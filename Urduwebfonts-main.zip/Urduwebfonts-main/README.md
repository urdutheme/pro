# Urduwebfonts
Google alternative Urdu web fonts to embed in your blog or website for free.
<br />
اگر آپ ان فانٹس میں سے کسی ایک کے بھی مالک ہیں اور آپ نہیں چاہتے کہ یہ فانٹس آپ کے اجازت کے بغیر استعمال ہو تو برائے کرم کسی بھی طرح کا قدم اٹھانے سے پہلے مجھ سے ایک بار اس ای میل پر رابطہ ضرورکر لیں۔ 
<br />
 * [Demo](https://humayunxhan.github.io/Urduwebfonts)
- Css Link: `https://humayunxhan.github.io/Urduwebfonts/sameer%20klek/stylesheet.css`_

humayunkhan108@gmail.com
